refind-black
============

Minimalistic, flat, black and white theme for [rEFInd](http://www.rodsbooks.com/refind/).
Heavily inspired by [rEFInd-minimal](https://github.com/EvanPurkhiser/rEFInd-minimal)

![screenshot](http://i.imgur.com/Pqg4Frk.png)

![screenshot](http://i.imgur.com/WBr2chP.png)

![screenshot](http://i.imgur.com/B3pN0N1.png)
